Remember This course is still on progress so you will all the updates visiting our website geekyshows.com 
Whenever i will update this course you will see update badge in the
Dashboard ---> My Notes ---> Download


Currently you will get Source code only but in future you will also get PDF file.